document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".heart").forEach(button => {
    button.addEventListener("click", () => {
      button.classList.toggle("saved");
      button.textContent = button.classList.contains("saved") ? "♥" : "♡";
      button.setAttribute("aria-label", button.classList.contains("saved") ? "Remove saved car" : "Save car");
    });
  });

  const clear = document.getElementById("clearFilters");
  if (clear) {
    clear.addEventListener("click", () => {
      document.querySelectorAll(".filters select").forEach(select => select.selectedIndex = 0);
      document.querySelectorAll(".filters input[type=checkbox]").forEach(input => input.checked = false);
    });
  }

  document.querySelectorAll("form").forEach(form => {
    if (form.classList.contains("search-panel")) return;
    form.addEventListener("submit", event => {
      event.preventDefault();
      const button = form.querySelector("button[type=submit]");
      if (button) {
        const original = button.textContent;
        button.textContent = "Submitted ✓";
        setTimeout(() => button.textContent = original, 1800);
      }
    });
  });
});
