const modelsByMake = {
    BMW: [
        "1 Series",
        "2 Series",
        "3 Series",
        "4 Series",
        "5 Series",
        "7 Series",
        "M2",
        "M3",
        "M4",
        "M5",
        "X1",
        "X3",
        "X5",
        "X6",
        "X7"
    ],

    "Mercedes-Benz": [
        "A-Class",
        "C-Class",
        "E-Class",
        "S-Class",
        "CLA",
        "GLA",
        "GLC",
        "GLE",
        "GLS",
        "AMG GT"
    ],

    Audi: [
        "A1",
        "A3",
        "A4",
        "A5",
        "A6",
        "A7",
        "A8",
        "Q3",
        "Q5",
        "Q7",
        "Q8",
        "RS3",
        "RS4",
        "RS5",
        "RS6",
        "RS7",
        "R8"
    ],

    Toyota: [
        "Agya",
        "Corolla",
        "Corolla Cross",
        "Fortuner",
        "Hilux",
        "Land Cruiser",
        "RAV4",
        "Starlet",
        "Supra",
        "Urban Cruiser"
    ]
};

const make = document.getElementById("make");
const model = document.getElementById("model");

make.addEventListener("change", function () {

    model.innerHTML = "";

    if (this.value === "") {
        model.disabled = true;

        const option = document.createElement("option");
        option.textContent = "Choose a make first";
        model.appendChild(option);

        return;
    }

    model.disabled = false;

    const firstOption = document.createElement("option");
    firstOption.textContent = "Any " + this.value + " model";
    firstOption.value = "";
    model.appendChild(firstOption);

    modelsByMake[this.value].forEach(function(carModel) {

        const option = document.createElement("option");

        option.value = carModel;
        option.textContent = carModel;

        model.appendChild(option);
    });
});